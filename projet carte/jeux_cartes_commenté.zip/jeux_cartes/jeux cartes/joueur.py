class Joueur:
    def __init__(self, nom):
        self.nom = nom
        self.main = []  # Liste pour stocker les cartes du joueur

    def ajouter_carte(self, carte):
        self.main.append(carte)  # Ajoute une carte à la main du joueur

    def afficher_main(self):
        print(f"Main du joueur {self.nom}:")
        for i, carte in enumerate(self.main, start=1):
            print(f"{i}. {carte}")  # Affiche la main du joueur

    def jouer_carte(self, couleur_demandee, premier_tour=True):
        # Vérifie s'il s'agit du premier tour et si le joueur a un 7 de cœur
        if premier_tour and any(carte.valeur == 7 and carte.couleur == "COEUR" for carte in self.main):
            cartes_possibles = [carte for carte in self.main if carte.couleur != "COEUR"]
            if self.main != cartes_possibles:
                print(f"{self.nom} commence car il possède le 7 de COEUR.")
        else:
            cartes_possibles = self.main

        # Récupère les cartes de la couleur demandée
        cartes_couleur_demandee = [carte for carte in cartes_possibles if carte.couleur == couleur_demandee]

        if cartes_couleur_demandee:
            # S'il y a des cartes de la couleur demandée, joue celle avec le moins de points
            carte_a_jouer = min(cartes_couleur_demandee, key=lambda carte: carte.points())
        else:
            # S'il n'y a pas de cartes de la couleur demandée, joue celle avec le moins de points parmi toutes les cartes possibles
            carte_a_jouer = min(cartes_possibles, key=lambda carte: carte.points())

        self.main.remove(carte_a_jouer)  # Retire la carte jouée de la main du joueur
        premier_tour = False
        return carte_a_jouer  # Renvoie la carte jouée

    def ramasser_pli(self, pli):
        self.main.extend(pli)  # Ajoute les cartes du pli à la main du joueur

    def calculer_points(self):
        return sum(carte.points() for carte in self.main)  # Calcule le total des points de la main du joueur
